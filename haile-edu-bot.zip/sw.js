const STATIC_CACHE_NAME = 'haile-edu-bot-static-v3';
const DYNAMIC_CACHE_NAME = 'haile-edu-bot-dynamic-v3';

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/index.tsx',
  '/App.tsx',
  '/contexts/i18nContext.tsx',
  '/components/SplashScreen.tsx',
  '/components/SignInScreen.tsx',
  '/components/Icons.tsx',
  '/i18n/en.json',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache and precaching static assets');
        return cache.addAll(PRECACHE_URLS);
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== STATIC_CACHE_NAME && cacheName !== DYNAMIC_CACHE_NAME) {
              console.log('Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      }).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Stale-while-revalidate strategy
  event.respondWith(
    caches.match(request).then(cachedResponse => {
      const fetchPromise = fetch(request).then(networkResponse => {
        if (networkResponse.ok) {
            let cacheName = DYNAMIC_CACHE_NAME;
            const fileExtension = url.pathname.split('.').pop();
            const staticAssetExtensions = ['js', 'css', 'tsx', 'ts', 'svg', 'png', 'jpg', 'jpeg', 'json'];
            
            if (PRECACHE_URLS.includes(url.pathname) || staticAssetExtensions.includes(fileExtension)) {
                cacheName = STATIC_CACHE_NAME;
            }
            
            caches.open(cacheName).then(cache => {
                cache.put(request, networkResponse.clone());
            });
        }
        return networkResponse;
      });

      // Return cached response if available, otherwise wait for fetch.
      return cachedResponse || fetchPromise;
    }).catch(() => {
        // This will be triggered if both cache match and fetch fail.
        // Can return a fallback page here.
    })
  );
});
import React, { useState, useEffect } from 'react';
import { BackIcon, HistoryNavIcon, TrashIcon } from './Icons';
import type { ChatSession } from '../types';
import { useI18n } from '../contexts/i18nContext';

interface HistoryProps {
  onBack: () => void;
  onLoadSession: (session: ChatSession) => void;
}

const History: React.FC<HistoryProps> = ({ onBack, onLoadSession }) => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const { t, language } = useI18n();

  useEffect(() => {
    const history = JSON.parse(localStorage.getItem('chatHistory') || '[]') as ChatSession[];
    history.sort((a, b) => b.timestamp - a.timestamp);
    setSessions(history);
  }, []);
  
  const handleClearHistory = () => {
    if (window.confirm(t('historyClearConfirm'))) {
        localStorage.removeItem('chatHistory');
        setSessions([]);
    }
  }

  const formatTimestamp = (timestamp: number) => {
    const options: Intl.DateTimeFormatOptions = {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    };
    try {
        return new Date(timestamp).toLocaleDateString(language, options);
    } catch (e) {
        console.warn(`Could not format date for locale "${language}", falling back to en-US.`);
        return new Date(timestamp).toLocaleDateString('en-US', options);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--background-primary)] text-[var(--text-primary)] max-w-md mx-auto">
      <header className="flex items-center justify-between p-4 border-b border-[var(--border-color)]">
        <div className="flex items-center">
            <button onClick={onBack} className="p-2 mr-2">
            <BackIcon className="w-6 h-6" />
            </button>
            <h1 className="text-lg font-bold">{t('historyHeader')}</h1>
        </div>
        {sessions.length > 0 && (
             <button onClick={handleClearHistory} className="p-2 text-[var(--text-secondary)] hover:text-[var(--destructive)]">
                <TrashIcon className="w-5 h-5" />
            </button>
        )}
      </header>
      <main className="flex-1 overflow-y-auto">
        {sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-[var(--text-secondary)]">
            <HistoryNavIcon className="w-16 h-16 mb-4" />
            <h2 className="text-xl font-semibold">{t('historyEmptyTitle')}</h2>
            <p className="text-center mt-2">{t('historyEmptySubtitle')}</p>
          </div>
        ) : (
          <ul className="p-4 space-y-3">
            {sessions.map((session) => (
              <li key={session.id}>
                <button
                  onClick={() => onLoadSession(session)}
                  className="w-full text-left bg-[var(--background-secondary)] p-4 rounded-lg hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all"
                >
                  <p className="font-semibold text-[var(--text-primary)] truncate">{session.title}</p>
                  <p className="text-xs text-[var(--text-secondary)] mt-1">{formatTimestamp(session.timestamp)}</p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
};

export default History;
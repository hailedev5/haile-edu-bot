

export type Model = 'gemini-2.5-flash' | 'gemini-2.5-pro';

export interface Attachment {
  name: string;
  type: 'image' | 'pdf';
  dataUrl: string; // for rendering
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  attachment?: Attachment;
}

export interface ChatSession {
  id:string;
  title: string;
  messages: Message[];
  timestamp: number;
}

export interface SavedMessage extends Message {
  savedAt: number;
}

export type AuthProvider = 'google' | 'instagram' | 'telegram' | 'tiktok' | 'facebook';

export interface LinkedAccount {
  provider: AuthProvider;
  id: string; // e.g., email or username
  displayName: string;
  picture?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  picture?: string; // Base64 data URL
  linkedAccounts: LinkedAccount[];
}

export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface BookPreferences {
  tone: 'Formal' | 'Informal' | 'Humorous';
  length: '5' | '10' | '15';
  audience: 'Beginner' | 'Intermediate' | 'Expert';
}

export interface DictionaryEntry {
  word: string;
  phonetic: string;
  meanings: {
    partOfSpeech: string;
    definitions: {
      definition: string;
      example?: string;
    }[];
  }[];
}

export interface PeriodicElement {
    name: string;
    symbol: string;
    number: number;
    atomic_mass: number;
    category: string;
    density: number | null;
    melt: number | null;
    boil: number | null;
    electron_configuration_semantic: string;
    summary: string;
    xpos: number;
    ypos: number;
}

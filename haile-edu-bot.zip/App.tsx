
import React, { useState, useEffect, useRef } from 'react';
import ChatInterface from './components/ChatInterface';
import SignInScreen from './components/SignInScreen';
import SplashScreen from './components/SplashScreen';
import Profile from './components/Profile';
import History from './components/History';
import Saved from './components/Saved';
import PracticeQuizzes from './components/PracticeQuizzes';
import StudyGuides from './components/StudyGuides';
import FlashcardsGenerator from './components/FlashcardsGenerator';
import Settings from './components/Settings';
import AboutScreen from './components/AboutScreen';
import ShareScreen from './components/ShareScreen';
import AITutorScreen from './components/AITutorScreen';
import BooksScreen from './components/BooksScreen';
import TodoList from './components/TodoList';
import AnswerChecker from './components/AnswerChecker';
import DictionaryScreen from './components/DictionaryScreen';
import TranslationScreen from './components/TranslationScreen';
import PeriodicTable from './components/PeriodicTable';
import OfflineIndicator from './components/OfflineIndicator';
import InstallPWAButton from './components/InstallPWAButton';
import ApiKeyScreen from './components/ApiKeyScreen';
import type { ChatSession, UserProfile, BookPreferences, LinkedAccount, Model } from './types';
import {
  RobotIcon, UserCircleIcon, SettingsIcon, MicIcon, MoreIcon,
  MathIcon, HistoryIcon, LiteratureIcon, CodingIcon, ScienceIcon,
  QuizIcon, FlashcardsIcon, StudyGuideIcon, TutorIcon,
  HomeIcon, HistoryNavIcon, SavedIcon, ProfileIcon, InfoIcon, ShareIcon,
  BookIcon, TodoListIcon, AnswerCheckerIcon, DictionaryIcon, TranslateIcon, PeriodicTableIcon, ImageIcon
} from './components/Icons';
import { useI18n } from './contexts/i18nContext';
import ImageGenerator from './components/ImageGenerator';
import VoiceInputOverlay from './components/VoiceInputOverlay';


export type Theme = 'dark' | 'light' | 'night' | 'dusk' | 'forest' | 'ocean';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [view, setView] = useState<'home' | 'chat' | 'profile' | 'history' | 'saved' | 'quizzes' | 'studyGuides' | 'flashcards' | 'settings' | 'about' | 'share' | 'aiTutor' | 'books' | 'todo' | 'answerChecker' | 'dictionary' | 'translation' | 'periodicTable' | 'imageGenerator'>('home');
  const [initialQuery, setInitialQuery] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [activeSession, setActiveSession] = useState<ChatSession | null>(null);
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('appTheme') as Theme) || 'dark');
  const [model, setModel] = useState<Model>(() => (localStorage.getItem('appModel') as Model) || 'gemini-2.5-flash');
  const [isRecording, setIsRecording] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isInternetSavingMode, setIsInternetSavingMode] = useState(() => localStorage.getItem('internetSavingMode') === 'true');
  const [recentQuestions, setRecentQuestions] = useState<string[]>([]);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);
  const { t, language } = useI18n();

  const recognitionRef = useRef<any | null>(null);
  const finalTranscriptRef = useRef('');
  
  useEffect(() => {
    const savedApiKey = localStorage.getItem('geminiApiKey');
    if (savedApiKey) {
      setApiKey(savedApiKey);
    }
  }, []);

  useEffect(() => {
    try {
        const savedProfile = localStorage.getItem('userProfile');
        if (savedProfile) {
            const profile = JSON.parse(savedProfile);
            setUserProfile(profile);
            setIsSignedIn(true);
        }
    } catch (e) {
        console.error("Failed to load user profile:", e);
        setUserProfile(null);
        setIsSignedIn(false);
    }
  }, []);

  const handleApiKeySubmit = (key: string) => {
    localStorage.setItem('geminiApiKey', key);
    setApiKey(key);
  };

  const handleSignIn = (account: LinkedAccount) => {
    const newProfile: UserProfile = {
      name: account.displayName,
      email: account.id,
      picture: account.picture,
      linkedAccounts: [account],
    };
    setUserProfile(newProfile);
    setIsSignedIn(true);
    localStorage.setItem('userProfile', JSON.stringify(newProfile));
  };

  const handleSignOut = () => {
    setUserProfile(null);
    setIsSignedIn(false);
    localStorage.removeItem('userProfile');
    setView('home'); // Navigate to home to show SignInScreen
  };

  const handleProfileUpdate = (newProfile: UserProfile) => {
    setUserProfile(newProfile);
    localStorage.setItem('userProfile', JSON.stringify(newProfile));
  };


  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    document.body.className = `theme-${theme}`;
    localStorage.setItem('appTheme', theme);
  }, [theme]);
  
  useEffect(() => {
    localStorage.setItem('appModel', model);
  }, [model]);

  useEffect(() => {
    localStorage.setItem('internetSavingMode', String(isInternetSavingMode));
  }, [isInternetSavingMode]);

  useEffect(() => {
    // Load recent questions when returning to home screen
    if (view === 'home') {
      try {
        const history = JSON.parse(localStorage.getItem('chatHistory') || '[]') as ChatSession[];
        history.sort((a, b) => b.timestamp - a.timestamp);
        const questions = history
          .slice(0, 2) // Get the two most recent sessions
          .map(session => session.messages.find(msg => msg.role === 'user')?.content)
          .filter((q): q is string => !!q && q.trim().length > 0);
        setRecentQuestions(questions);
      } catch (e) {
        console.error("Failed to parse chat history:", e);
        setRecentQuestions([]);
      }
    }
  }, [view]);
  
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
      setShowInstallBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  useEffect(() => {
    if (!('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      console.error("Speech Recognition not supported by this browser.");
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = language;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    
    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscriptRef.current += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setInputValue(finalTranscriptRef.current + interimTranscript);
    };
    
    recognition.onerror = (event: any) => {
        if (event.error !== 'aborted' && event.error !== 'no-speech') {
          console.error('Speech recognition error', event.error);
        }
        setIsRecording(false);
    }

    recognitionRef.current = recognition;
    
    return () => {
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }
    };
  }, [language]);


  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    if (recognitionRef.current && isRecording) {
      recognitionRef.current.stop();
    }
    if (inputValue.trim()) {
      setInitialQuery(inputValue.trim());
      setActiveSession(null);
      setView('chat');
      setInputValue('');
    }
  };

  const handleMicButtonClick = async () => {
    const recognition = recognitionRef.current;
    if (!recognition) return;

    if (isRecording) {
      recognition.stop();
    } else {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        
        finalTranscriptRef.current = '';
        setInputValue('');
        recognition.start();
      } catch (error) {
        console.error('Error requesting microphone permission:', error);
        if ((error as DOMException).name === 'NotAllowedError' || (error as DOMException).name === 'PermissionDeniedError') {
          alert(t('microphonePermissionError'));
        }
        setIsRecording(false);
      }
    }
  };


  const handleStartQuiz = (topic: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(`Start a practice quiz on ${topic}. Give me the first multiple-choice question.`);
    setActiveSession(null);
    setView('chat');
  };

  const handleStartStudyGuide = (topic: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(`Generate a comprehensive study guide on ${topic}. Include key concepts, important figures, and a summary.`);
    setActiveSession(null);
    setView('chat');
  };
  
  const handleStartFlashcards = (topic: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(`Generate a set of 5 flashcards for the topic: "${topic}". For each flashcard, provide a 'Question:' and a corresponding 'Answer:'. Format them clearly with markdown headings for each part.`);
    setActiveSession(null);
    setView('chat');
  };
  
  const handleStartTutorSession = (topic: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(`Start an AI tutor session on the topic: "${topic}". Act as a Socratic tutor. Begin by asking me a question to gauge my understanding of the topic, and then guide me through the concepts with questions instead of just giving me the answers.`);
    setActiveSession(null);
    setView('chat');
  };

  const handleStartBookGeneration = (topic: string, prefs: BookPreferences) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    const prompt = `Generate an educational book on the topic: "${topic}". 
      The book should be written for a ${prefs.audience} audience. 
      The tone should be ${prefs.tone}. 
      It should have approximately ${prefs.length} chapters. 
      Start with a title and a table of contents, then write Chapter 1.`;
      
    setInitialQuery(prompt);
    setActiveSession(null);
    setView('chat');
  };
  
  const handleInstallClick = async () => {
    if (!deferredInstallPrompt) {
      return;
    }
    setShowInstallBanner(false);
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    console.log(`User response to the install prompt: ${outcome}`);
    setDeferredInstallPrompt(null);
  };

  const handleInstallDismiss = () => {
    setShowInstallBanner(false);
  };

  const handleRecentQuestionClick = (question: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(question);
    setActiveSession(null);
    setView('chat');
  };

  const handleSubjectClick = (subject: string) => {
    if (!isOnline) {
      alert(t('offlineSearchError'));
      return;
    }
    setInitialQuery(`Explain the basics of ${subject}.`);
    setActiveSession(null);
    setView('chat');
  };

  const navigate = (newView: 'home' | 'profile' | 'history' | 'saved') => {
    setView(newView);
    setActiveSession(null);
    setInitialQuery('');
  }

  if (showSplash) {
    return <SplashScreen />;
  }

  if (!apiKey) {
    return <ApiKeyScreen onApiKeySubmit={handleApiKeySubmit} />;
  }
  
  if (!isSignedIn || !userProfile) {
    return <SignInScreen onSignIn={handleSignIn} />;
  }

  if (view === 'chat') {
    return <>
        {!isOnline && <OfflineIndicator />}
        <ChatInterface 
          key={activeSession?.id || 'new'}
          session={activeSession} 
          initialQuery={initialQuery} 
          onBack={() => setView('home')}
          isOnline={isOnline}
          isInternetSavingMode={isInternetSavingMode}
          model={model}
        />
    </>;
  }

  if (view === 'profile') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <Profile 
        userProfile={userProfile}
        onUpdateProfile={handleProfileUpdate}
        onBack={() => setView('home')} 
        onSignOut={handleSignOut} 
      />
    </>;
  }

  if (view === 'settings') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <Settings 
        onBack={() => setView('home')} 
        currentTheme={theme} 
        onChangeTheme={setTheme} 
        currentModel={model}
        onChangeModel={setModel}
        isInternetSavingMode={isInternetSavingMode}
        onSetInternetSavingMode={setIsInternetSavingMode}
        onInstallApp={handleInstallClick}
        canInstallPWA={!!deferredInstallPrompt}
      />
    </>;
  }
  
  if (view === 'about') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <AboutScreen onBack={() => setView('home')} />
    </>;
  }

  if (view === 'share') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <ShareScreen onBack={() => setView('home')} />
    </>;
  }
  
  if (view === 'quizzes') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <PracticeQuizzes onBack={() => setView('home')} onStartQuiz={handleStartQuiz} />
    </>;
  }

  if (view === 'studyGuides') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <StudyGuides onBack={() => setView('home')} onStartStudyGuide={handleStartStudyGuide} />
    </>;
  }

  if (view === 'flashcards') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <FlashcardsGenerator onBack={() => setView('home')} onStartFlashcards={handleStartFlashcards} />
    </>;
  }

  if (view === 'aiTutor') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <AITutorScreen onBack={() => setView('home')} onStartTutorSession={handleStartTutorSession} />
    </>;
  }
  
  if (view === 'books') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <BooksScreen onBack={() => setView('home')} onStartBookGeneration={handleStartBookGeneration} />
    </>;
  }

  if (view === 'todo') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <TodoList onBack={() => setView('home')} />
    </>;
  }

  if (view === 'answerChecker') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <AnswerChecker onBack={() => setView('home')} model={model} />
    </>;
  }
  
  if (view === 'dictionary') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <DictionaryScreen onBack={() => setView('home')} model={model} />
    </>;
  }

  if (view === 'translation') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <TranslationScreen onBack={() => setView('home')} model={model} />
    </>;
  }

  if (view === 'periodicTable') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <PeriodicTable onBack={() => setView('home')} />
    </>;
  }

  if (view === 'history') {
    return <>
        {!isOnline && <OfflineIndicator />}
        <History 
          onBack={() => navigate('home')} 
          onLoadSession={(session) => {
            setActiveSession(session);
            setView('chat');
          }} 
        />
    </>;
  }
  
  if (view === 'imageGenerator') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <ImageGenerator onBack={() => setView('home')} isOnline={isOnline} isInternetSavingMode={isInternetSavingMode} />
    </>;
  }

  if (view === 'saved') {
    return <>
      {!isOnline && <OfflineIndicator />}
      <Saved onBack={() => navigate('home')} />
    </>;
  }


  return (
    <div className="bg-[var(--background-primary)] min-h-screen text-[var(--text-primary)] font-['Poppins']">
      <VoiceInputOverlay isVisible={isRecording} transcript={inputValue} onClose={handleMicButtonClick} />
      {!isOnline && <OfflineIndicator />}
      {showInstallBanner && deferredInstallPrompt && (
        <InstallPWAButton onInstall={handleInstallClick} onDismiss={handleInstallDismiss} />
      )}
      <div className="max-w-md mx-auto">
        <header className="flex justify-between items-center p-4 pt-6">
          <div className="flex items-center gap-2">
            <RobotIcon className="w-10 h-10" />
            <div>
              <h1 className="text-lg font-bold tracking-wider">{t('haile')}</h1>
              <p className="text-xs text-[var(--accent-primary)]">{t('appSlogan')}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setView('share')} aria-label={t('share')}>
                <ShareIcon className="w-6 h-6 text-[var(--text-secondary)]" />
            </button>
            <button onClick={() => setView('about')} aria-label={t('about')}>
                <InfoIcon className="w-6 h-6 text-[var(--text-secondary)]" />
            </button>
            <button onClick={() => setView('settings')} aria-label={t('settings')}>
                <SettingsIcon className="w-6 h-6 text-[var(--text-secondary)]" />
            </button>
          </div>
        </header>

        <main className="p-4 space-y-8 pb-28">
          <form onSubmit={handleSearchSubmit} className="relative mt-4">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={!isOnline ? t('offlineNoSearch') : (isRecording ? t('listening') : t('searchPlaceholder'))}
              className="w-full bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-full py-3 pl-5 pr-12 text-[var(--text-primary)] placeholder-[var(--text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-primary)] disabled:opacity-60"
              disabled={!isOnline}
            />
            <button type="button" onClick={handleMicButtonClick} aria-label="Use microphone" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 disabled:opacity-60" disabled={!isOnline}>
              <MicIcon className={`w-6 h-6 transition-colors ${isRecording ? 'text-[var(--destructive)]' : 'text-[var(--accent-primary)]'}`} />
            </button>
          </form>

          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold">{t('recentQuestions')}</h2>
              <button onClick={() => navigate('history')} aria-label={t('viewAllHistory')}>
                <MoreIcon className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            {recentQuestions.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {recentQuestions.map((question, index) => (
                  <button
                    key={index}
                    onClick={() => handleRecentQuestionClick(question)}
                    className="bg-[var(--background-secondary)] p-3 rounded-lg text-sm text-left h-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all focus:outline-none focus:ring-2 focus:ring-[var(--accent-primary)]"
                  >
                    <p className="line-clamp-3">{question}</p>
                  </button>
                ))}
              </div>
            ) : (
              <div className="bg-[var(--background-secondary)] p-4 rounded-lg text-center text-sm text-[var(--text-secondary)]">
                {t('noRecentQuestions')}
              </div>
            )}
          </section>

          <section>
            <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold">{t('popularSubjects')}</h2>
                <MoreIcon className="w-5 h-5 text-gray-500" />
            </div>
            <div className="flex justify-around items-start">
                <button onClick={() => handleSubjectClick(t('mathematics'))} className="flex flex-col items-center gap-2 text-center w-16 group focus:outline-none" aria-label={`${t('learnAbout')} ${t('mathematics')}`}>
                    <div className="p-4 border-2 border-[var(--border-color)] rounded-full group-hover:bg-[var(--accent-primary)]/10 group-hover:border-[var(--accent-primary)]/50 transition-all transform group-focus:ring-2 group-focus:ring-[var(--accent-primary)]">
                        <MathIcon className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)] transition-colors" />
                    </div>
                    <span className="text-xs text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{t('mathematics')}</span>
                </button>
                <button onClick={() => handleSubjectClick(t('history'))} className="flex flex-col items-center gap-2 text-center w-16 group focus:outline-none" aria-label={`${t('learnAbout')} ${t('history')}`}>
                    <div className="p-4 border-2 border-[var(--border-color)] rounded-full group-hover:bg-[var(--accent-primary)]/10 group-hover:border-[var(--accent-primary)]/50 transition-all transform group-focus:ring-2 group-focus:ring-[var(--accent-primary)]">
                        <HistoryIcon className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)] transition-colors" />
                    </div>
                    <span className="text-xs text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{t('history')}</span>
                </button>
                <button onClick={() => handleSubjectClick(t('literature'))} className="flex flex-col items-center gap-2 text-center w-16 group focus:outline-none" aria-label={`${t('learnAbout')} ${t('literature')}`}>
                    <div className="p-4 border-2 border-[var(--border-color)] rounded-full group-hover:bg-[var(--accent-primary)]/10 group-hover:border-[var(--accent-primary)]/50 transition-all transform group-focus:ring-2 group-focus:ring-[var(--accent-primary)]">
                        <LiteratureIcon className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)] transition-colors" />
                    </div>
                    <span className="text-xs text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{t('literature')}</span>
                </button>
                <button onClick={() => handleSubjectClick(t('coding'))} className="flex flex-col items-center gap-2 text-center w-16 group focus:outline-none" aria-label={`${t('learnAbout')} ${t('coding')}`}>
                    <div className="p-4 border-2 border-[var(--border-color)] rounded-full group-hover:bg-[var(--accent-primary)]/10 group-hover:border-[var(--accent-primary)]/50 transition-all transform group-focus:ring-2 group-focus:ring-[var(--accent-primary)]">
                        <CodingIcon className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)] transition-colors" />
                    </div>
                    <span className="text-xs text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{t('coding')}</span>
                </button>
                <button onClick={() => handleSubjectClick(t('science'))} className="flex flex-col items-center gap-2 text-center w-16 group focus:outline-none" aria-label={`${t('learnAbout')} ${t('science')}`}>
                    <div className="p-4 border-2 border-[var(--border-color)] rounded-full group-hover:bg-[var(--accent-primary)]/10 group-hover:border-[var(--accent-primary)]/50 transition-all transform group-focus:ring-2 group-focus:ring-[var(--accent-primary)]">
                        <ScienceIcon className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)] transition-colors" />
                    </div>
                    <span className="text-xs text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{t('science')}</span>
                </button>
            </div>
          </section>

          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold">{t('studyTools')}</h2>
              <MoreIcon className="w-5 h-5 text-gray-500" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setView('quizzes')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <QuizIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('practiceQuizzes')}</span>
              </button>
              <button onClick={() => setView('flashcards')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <FlashcardsIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('flashcards')}</span>
              </button>
              <button onClick={() => setView('studyGuides')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <StudyGuideIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('studyGuides')}</span>
              </button>
              <button onClick={() => setView('aiTutor')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <TutorIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('aiTutor')}</span>
              </button>
               <button onClick={() => setView('dictionary')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <DictionaryIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('dictionary')}</span>
              </button>
              <button onClick={() => setView('translation')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <TranslateIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('translation')}</span>
              </button>
              <button onClick={() => setView('answerChecker')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <AnswerCheckerIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('answerChecker')}</span>
              </button>
              <button onClick={() => setView('todo')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <TodoListIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('todoList')}</span>
              </button>
              <button onClick={() => setView('periodicTable')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <PeriodicTableIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('periodicTable')}</span>
              </button>
              <button onClick={() => setView('books')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <BookIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('books')}</span>
              </button>
              <button onClick={() => setView('imageGenerator')} className="bg-[var(--background-secondary)] p-3 rounded-lg flex flex-col items-center text-center gap-2 w-full hover:bg-[var(--accent-primary)]/10 border border-transparent hover:border-[var(--accent-primary)]/50 transition-all">
                <ImageIcon className="w-8 h-8 text-[var(--accent-primary)]" />
                <span className="text-xs font-medium">{t('imageGenerator')}</span>
              </button>
            </div>
          </section>
        </main>

        <nav className="fixed bottom-0 left-0 right-0 bg-[var(--background-secondary)]/80 backdrop-blur-sm border-t border-[var(--border-color)] max-w-md mx-auto rounded-t-2xl">
          <div className="flex justify-around items-center h-20">
            <button onClick={() => navigate('home')} className={`flex flex-col items-center gap-1 ${view === 'home' ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`}>
              <HomeIcon className="w-6 h-6" />
              <span className="text-xs font-semibold">{t('navHome')}</span>
            </button>
            <button onClick={() => navigate('history')} className={`flex flex-col items-center gap-1 ${view === 'history' ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`}>
              <HistoryNavIcon className="w-6 h-6" />
              <span className="text-xs">{t('navHistory')}</span>
            </button>
            <button onClick={() => navigate('saved')} className={`flex flex-col items-center gap-1 ${view === 'saved' ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`}>
              <SavedIcon className="w-6 h-6" />
              <span className="text-xs">{t('navSaved')}</span>
            </button>
            <button onClick={() => navigate('profile')} className={`flex flex-col items-center gap-1 ${view === 'profile' ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`}>
              {userProfile.picture ? (
                <img src={userProfile.picture} alt="Profile" className="w-6 h-6 rounded-full object-cover" />
              ) : (
                <ProfileIcon className="w-6 h-6" />
              )}
              <span className="text-xs">{t('navProfile')}</span>
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default App;
